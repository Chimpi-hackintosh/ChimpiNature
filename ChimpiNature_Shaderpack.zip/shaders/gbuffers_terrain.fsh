#version 120

// CONFIGURAVEL NO MENU DE SHADERS
#define COLOR_BOOST 1.05 // [1.0 1.05 1.10 1.15]

uniform sampler2D texture;
uniform sampler2D lightmap;
uniform vec3 fogColor;
uniform float far;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vcolor;
varying float fogDistance;

void main() {
    vec4 tex = texture2D(texture, texcoord) * vcolor;
    if (tex.a < 0.1) discard;
    vec3 lm = texture2D(lightmap, lmcoord).rgb;
    vec3 lit = tex.rgb * max(lm, vec3(0.18));
    vec3 improved = clamp(mix(vec3(dot(lit, vec3(0.2126, 0.7152, 0.0722))), lit, COLOR_BOOST), 0.0, 1.0);
    float fog = clamp((fogDistance - far * 0.70) / max(far * 0.30, 1.0), 0.0, 1.0);
    improved = mix(improved, fogColor, fog * 0.65);
    gl_FragData[0] = vec4(improved, tex.a);
}
