#version 120

// CONFIGURAVEL NO MENU DE SHADERS
#define WIND_STRENGTH 0.05 // [0.0 0.02 0.05 0.08]

attribute vec2 mc_Entity;
uniform float frameTimeCounter;
varying vec2 texcoord;
varying vec2 lmcoord;
varying vec4 vcolor;
varying float fogDistance;

void main() {
    vec4 p = gl_Vertex;
    float isPlant = float(abs(mc_Entity.x - 10001.0) < 0.5);
    float isLeaf = float(abs(mc_Entity.x - 10002.0) < 0.5);
    float strength = WIND_STRENGTH * (isPlant + isLeaf * 0.35);
    float wave = sin(frameTimeCounter * 1.8 + p.x * 0.65 + p.z * 0.85);
    p.x += wave * strength;
    p.z += cos(frameTimeCounter * 1.3 + p.z) * strength * 0.45;
    gl_Position = gl_ModelViewProjectionMatrix * p;
    texcoord = (gl_TextureMatrix[0] * gl_MultiTexCoord0).xy;
    lmcoord = (gl_TextureMatrix[1] * gl_MultiTexCoord1).xy;
    vcolor = gl_Color;
    fogDistance = length((gl_ModelViewMatrix * p).xyz);
}
